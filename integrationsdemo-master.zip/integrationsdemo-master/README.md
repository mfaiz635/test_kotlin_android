# Integrations Demo
[![CircleCI](https://circleci.com/gh/mubstimor/integrationsdemo.svg?style=svg)](https://circleci.com/gh/mubstimor/integrationsdemo) 
[![Maintainability](https://api.codeclimate.com/v1/badges/b767e35f00a25678cb9f/maintainability)](https://codeclimate.com/github/mubstimor/integrationsdemo/maintainability)
[![codecov](https://codecov.io/gh/mubstimor/integrationsdemo/branch/master/graph/badge.svg)](https://codecov.io/gh/mubstimor/integrationsdemo)